﻿Конфиг Deadlock от AliveEnjoyer (twitch.tv/aliveenjoyer)
Снят 22.11.2026. Компьютер: ноутбук ASUS ROG, Ryzen 9 5900HX, RTX 3070, экран 240 Гц.

Это ровно то, на чём я играю и стримлю. Это не «лучшие настройки для всех»: что подойдёт твоему
компьютеру, покажет замер в Deadlock Optimizer (https://aliveenjoyer.art/deadlock-optimizer/).


1. autoexec.cfg
---------------
Положи файл в  Steam\steamapps\common\Deadlock\game\citadel\cfg\
Если autoexec.cfg там уже есть, допиши три строки из моего в конец своего.

  fps_max 180               потолок FPS в матче
  fps_max_ui 120            потолок FPS в меню
  engine_no_focus_sleep 0   игра не засыпает, когда её окно не в фокусе (стрим, второй монитор)


2. Настройки видео (ставятся в меню игры: Settings -> Video)
------------------------------------------------------------
Файл с этими настройками привязан к видеокарте, и чужой может уронить игру, поэтому в архиве его нет.
Названия пунктов — как в английском меню игры; у Distance Field, Displacement Mapping, Depth of Field и
Motion Blur строка в меню может называться чуть иначе.

  Window Mode              Full Screen
  Resolution               1680 x 1050, 240 Гц
  Upscaling Technology     FSR
  Render Quality           67 %
  Anti-Aliasing            FXAA
  Shadow Quality           Low
  Screen Space AO          Off
  Distance Field AO        Off
  Distance Field Shadows   Off
  Distance Field Reflections   Off
  Fog Quality              Low
  Texture Quality          Low
  Area Lights              On
  Displacement Mapping     On
  Post Process Bloom       Off
  Effects Bloom            Off
  Depth of Field           Off
  Motion Blur              Off
  VSync                    Off
  NVIDIA Reflex Low Latency   Enabled
  FPS Cap в меню           240 (в матче действует 180 из autoexec.cfg)


3. Мышь и камера (Settings -> Options)
--------------------------------------
  Чувствительность мыши    1.14
  Поле зрения камеры       90


4. Необязательно: четыре строки в gameinfo.gi
---------------------------------------------
Файл:  Steam\steamapps\common\Deadlock\game\citadel\gameinfo.gi
Раздел ConVars { ... }, перед его закрывающей скобкой:

		"cl_ragdoll_limit" "0"
		"r_grass_quality" "0"
		"sc_clutter_enable" "false"
		"r_aspectratio" "2.44"

  cl_ragdoll_limit 0       тела после смерти не остаются «тряпичными куклами»: меньше работы процессору
  r_grass_quality 0        трава проще
  sc_clutter_enable false  без мелкого мусора на карте
  r_aspectratio 2.44       картинка рисуется под экран 2,44:1: обзор по горизонтали шире

Важно:
  - Сначала сделай копию gameinfo.gi. С ошибкой в этом файле игра не запустится; вернёшь копию — запустится.
  - Обновление игры может вернуть свой gameinfo.gi. Тогда строки нужно вписать заново.
  - Без этого блока всё остальное работает так же.


Чего в конфиге нет
------------------
Параметры запуска у меня только служебные, для инструментов стрима; на FPS они не влияют.
Бинды и моды сюда не входят.
