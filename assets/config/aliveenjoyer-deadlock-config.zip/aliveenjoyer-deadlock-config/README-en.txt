﻿AliveEnjoyer's Deadlock config (twitch.tv/aliveenjoyer)
Taken on November 22, 2026. Computer: ASUS ROG laptop, Ryzen 9 5900HX, RTX 3070, 240 Hz screen.

This is exactly what I play and stream on. It is not "the best settings for everyone": what suits your
computer is what a measurement in Deadlock Optimizer shows (https://aliveenjoyer.art/deadlock-optimizer/).


1. autoexec.cfg
---------------
Put the file into  Steam\steamapps\common\Deadlock\game\citadel\cfg\
If you already have an autoexec.cfg there, add the three lines of mine to the end of yours.

  fps_max 180               FPS cap in a match
  fps_max_ui 120            FPS cap in menus
  engine_no_focus_sleep 0   the game keeps full speed while its window is not focused (stream, second monitor)


2. Video settings (set them in the game: Settings -> Video)
-----------------------------------------------------------
The file that holds them is tied to the graphics card, and someone else's can crash the game, so it is not in
the archive. The names are those of the game's English menu; the lines for Distance Field, Displacement Mapping,
Depth of Field and Motion Blur may be worded slightly differently there.

  Window Mode              Full Screen
  Resolution               1680 x 1050, 240 Hz
  Upscaling Technology     FSR
  Render Quality           67%
  Anti-Aliasing            FXAA
  Shadow Quality           Low
  Screen Space AO          Off
  Distance Field AO        Off
  Distance Field Shadows   Off
  Distance Field Reflections   Off
  Fog Quality              Low
  Texture Quality          Low
  Area Lights              On
  Displacement Mapping     On
  Post Process Bloom       Off
  Effects Bloom            Off
  Depth of Field           Off
  Motion Blur              Off
  VSync                    Off
  NVIDIA Reflex Low Latency   Enabled
  FPS Cap in the menu      240 (in a match the 180 of autoexec.cfg applies)


3. Mouse and camera (Settings -> Options)
-----------------------------------------
  Mouse sensitivity        1.14
  Camera field of view     90


4. Optional: four lines in gameinfo.gi
--------------------------------------
File:  Steam\steamapps\common\Deadlock\game\citadel\gameinfo.gi
Section ConVars { ... }, before its closing brace:

		"cl_ragdoll_limit" "0"
		"r_grass_quality" "0"
		"sc_clutter_enable" "false"
		"r_aspectratio" "2.44"

  cl_ragdoll_limit 0       bodies do not stay as ragdolls: less work for the processor
  r_grass_quality 0        simpler grass
  sc_clutter_enable false  no small clutter on the map
  r_aspectratio 2.44       the picture is drawn for a 2.44:1 screen: a wider horizontal view

Important:
  - Copy gameinfo.gi first. With a mistake in this file the game does not start; put the copy back and it does.
  - A game update may bring back its own gameinfo.gi. The lines then have to be added again.
  - Everything else works the same without this block.


What is not in the config
-------------------------
My launch options are only service ones for my stream tools; they do not change FPS.
Key binds and mods are not included.
